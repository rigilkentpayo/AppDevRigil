﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AcrylicSYSTEM
{
    public partial class adminpage : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private int selectedRowIndex;

        public adminpage()
        {
            InitializeComponent();
        }
        private void clearfields()
        {
            
            txtFullname.Clear();
            txtLength.Clear();
            txtWidth.Clear();
            txtHeight.Clear();
            txtSides.Clear();
            txtAddress.Clear();
            
        }
        private void LoadData()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Orders.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM Orders", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "Orders");
                dataGridView1.DataSource = dataSet.Tables["Orders"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            /* try
             {
                 OleDbCommand command = new OleDbCommand("INSERT INTO Orders (order#, fullname, dateOrdered, address, sides, length, width, height) VALUES (@order#, @fullname, @dateOrdered, @address, @sides, @length, @width, @height)", connection);
                 command.Parameters.AddWithValue("@order#",int.Parse( txtOrdernum.Text));
                 command.Parameters.AddWithValue("@fullname", txtFullname.Text);
                 command.Parameters.AddWithValue("dateOrdered", (dateTimePicker1.Text));
                 command.Parameters.AddWithValue("@address",txtAddress.Text);
                 command.Parameters.AddWithValue("@sides", int.Parse(txtSides.Text));
                 command.Parameters.AddWithValue("@length", double.Parse(txtLength.Text));
                 command.Parameters.AddWithValue("@width", double.Parse(txtWidth.Text));
                 command.Parameters.AddWithValue("@height", double.Parse(txtHeight.Text));
                 command.ExecuteNonQuery();
                 MessageBox.Show("Data saved successfully.");
                 LoadData(); // Refresh the data in the DataGridView
             }
             catch (Exception ex)
             {
                 MessageBox.Show("Error: " + ex.Message);
             }
             finally
             {
                 if (connection != null && connection.State == ConnectionState.Open)
                 {
                     connection.Close();
                 }
             }
            */
            try
            {
                // Updated SQL query to match your database structure
                string sql = "INSERT INTO Orders (fullname,orderType, address, sides, length, width, height) VALUES (@fullname, @orderType, @address, @sides, @length, @width, @height)";

                // Assuming you are using an OleDb database provider
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\Orders.accdb")) 
                using (OleDbCommand command = new OleDbCommand(sql, conn))
                {
                    conn.Open();
                    command.Parameters.AddWithValue("@fullname", txtFullname.Text);
                    command.Parameters.AddWithValue("@orderType", comboBox1.Text);
                    command.Parameters.AddWithValue("@address", txtAddress.Text);
                    command.Parameters.AddWithValue("@sides", int.Parse(txtSides.Text));
                    command.Parameters.AddWithValue("@length", double.Parse(txtLength.Text));
                    command.Parameters.AddWithValue("@width", double.Parse(txtWidth.Text));
                    command.Parameters.AddWithValue("@height", double.Parse(txtHeight.Text));
                    command.ExecuteNonQuery();
                    MessageBox.Show("Data saved successfully.");
                    LoadData();
                }

                MessageBox.Show("Data has been added...", "Save new stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
                //clearfields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnNew_Click(object sender, EventArgs e)
        {
            clearfields();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        dataSet.Tables["Orders"].Rows[selectedRowIndex].Delete();

                        connection.Open();
                        OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                        dataAdapter.DeleteCommand = cmdBuilder.GetDeleteCommand();
                        dataAdapter.Update(dataSet, "Orders");

                        MessageBox.Show("Record deleted successfully.");
                        LoadData(); // Refresh the data in the DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    DataRow selectedRow = dataSet.Tables["Orders"].Rows[selectedRowIndex];

                    /*selectedRow["Name"] = txtName.Text;
                    selectedRow["Team"] = txtTeam.Text;*/
                    if (!string.IsNullOrEmpty(txtSides.Text))
                    {
                        selectedRow["sides"] = int.Parse(txtSides.Text);
                    }

                    if (!string.IsNullOrEmpty(txtLength.Text))
                    {
                        selectedRow["length"] = double.Parse(txtLength.Text);
                    }

                    if (!string.IsNullOrEmpty(txtWidth.Text))
                    {
                        selectedRow["width"] = double.Parse(txtWidth.Text);
                    }

                    if (!string.IsNullOrEmpty(txtHeight.Text))
                    {
                        selectedRow["height"] = double.Parse(txtHeight.Text);
                    }

                   

                    connection.Open();
                    OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                    dataAdapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
                    dataAdapter.Update(dataSet, "Orders");

                    MessageBox.Show("Data updated successfully.");
                    LoadData(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1[0, e.RowIndex].Value.ToString();
            txtFullname.Text = dataGridView1[1, e.RowIndex].Value.ToString();
            comboBox1.Text = dataGridView1[2, e.RowIndex].Value.ToString();
            txtAddress.Text = dataGridView1[3, e.RowIndex].Value.ToString();
            txtSides.Text = dataGridView1[4, e.RowIndex].Value.ToString();
            txtLength.Text = dataGridView1[5, e.RowIndex].Value.ToString();
            txtWidth.Text = dataGridView1[6, e.RowIndex].Value.ToString();
            txtHeight.Text = dataGridView1[7, e.RowIndex].Value.ToString();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

/*
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AdminRestock : Form
    {
        
        public AdminRestock()
        {
            InitializeComponent();
        }

        private void AdminRestock_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stocksDataSet.stocks' table. You can move, or remove it, as needed.
            this.stocksTableAdapter5.Fill(this.stocksDataSet.stocks);
            // TODO: This line of code loads data into the 'usersDataSet17.stocks' table. You can move, or remove it, as needed.
            this.stocksTableAdapter4.Fill(this.usersDataSet17.stocks);
            // TODO: This line of code loads data into the 'usersDataSet16.Query2' table. You can move, or remove it, as needed.
            this.query2TableAdapter4.Fill(this.usersDataSet16.Query2);
            
        }

        private void clearfields()
        {
            txtmaterialName.Clear();
            txtdesc.Clear();
            txtquantity.Clear();
            txtsupplier.Clear();
            txtlocation.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Updated SQL query to match your database structure
                string sql = "INSERT INTO stocks ( materialID, materialName, description, quantityOnHand, supplier, location) " +
                             "VALUES (@materialID, @materialName, @description, @quantityOnHand, @supplier, @location)";

                // Assuming you are using an OleDb database provider
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\hi\\Desktop\\EngineeringSystem\\WindowsFormsApp1\\users.accdb"))
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@materialID", txtmaterialID.Text);
                    cmd.Parameters.AddWithValue("@materialName", txtmaterialName.Text);
                    cmd.Parameters.AddWithValue("@description", txtdesc.Text);
                    cmd.Parameters.AddWithValue("@quantityOnHand", txtquantity.Text);
                    cmd.Parameters.AddWithValue("@supplier", txtsupplier.Text);
                    cmd.Parameters.AddWithValue("@location", txtlocation.Text);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Data has been added...", "Save new stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdminRestock_Load(sender, e);
                //clearfields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearfields();
        }

      
        private void button3_Click(object sender, EventArgs e)
        {
            try 
            {
                int stockID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value); // Adjust column index if needed 

                // Updated SQL query with WHERE clause
                string sql = "UPDATE stocks SET materialID = @materialID, materialName = @materialName, description = @description, quantityOnHand = @quantityOnHand, supplier = @supplier, location = @location WHERE materialID = @materialID";
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\hi\\Desktop\\EngineeringSystem\\WindowsFormsApp1\\users.accdb"))
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@materialID", txtmaterialID.Text);
                    cmd.Parameters.AddWithValue("@materialName", txtmaterialName.Text);
                    cmd.Parameters.AddWithValue("@description", txtdesc.Text);
                    cmd.Parameters.AddWithValue("@quantityOnHand", txtquantity.Text);
                    cmd.Parameters.AddWithValue("@supplier", txtsupplier.Text);
                    cmd.Parameters.AddWithValue("@location", txtlocation.Text);
                    cmd.Parameters.AddWithValue("@materialID", stockID);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Data has been updated...", "Update stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdminRestock_Load(sender, e);
            }
            catch 
            {
            
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void query2BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txtmaterialID.Text = dataGridView1[0, e.RowIndex].Value.ToString();
            txtmaterialName.Text = dataGridView1[1, e.RowIndex].Value.ToString();
            txtdesc.Text = dataGridView1[2, e.RowIndex].Value.ToString();
            txtquantity.Text = dataGridView1[3, e.RowIndex].Value.ToString();
            txtsupplier.Text = dataGridView1[4, e.RowIndex].Value.ToString();
            txtlocation.Text = dataGridView1[5, e.RowIndex].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                // Reload data into stocksTableAdapter4
                this.stocksTableAdapter4.Fill(this.usersDataSet17.stocks);

                // Optionally, reload data into query2TableAdapter4
                this.query2TableAdapter4.Fill(this.usersDataSet16.Query2);

                MessageBox.Show("Data grid view refreshed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error refreshing data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                // Confirmation message
                DialogResult confirmation = MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmation != DialogResult.Yes) return;  // Exit if user chooses 'No'

                // Get ID to delete
                int materialID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

                // Deletion query
                string sql = "DELETE FROM stocks WHERE materialID = @materialID";

                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\hi\\Desktop\\EngineeringSystem\\WindowsFormsApp1\\users.accdb"))
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@materialID", materialID);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Data has been deleted...", "Delete stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdminRestock_Load(sender, e); // Refresh data if needed
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
*/
