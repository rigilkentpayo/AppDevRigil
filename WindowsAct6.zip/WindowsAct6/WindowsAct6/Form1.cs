namespace WindowsAct6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1, num2, num3;

            double result, finalammount;
            double comm;
            num1 = Convert.ToDouble(txtnum1.Text);
            num2 = Convert.ToDouble(txtnum2.Text);
            num3 = Convert.ToDouble(txtnum3.Text);
            result = num1 + num2 + num3;
            String percent;
            percent = "";

            if (chk50.Checked)
            {
                comm = (result * .5);
                percent = "50%";
                finalammount = comm + result;

            }
            else if (chk10.Checked)
            {
                comm = (result * .1);
                percent = "10%";
                finalammount = comm + result;
            }
            else if (chk15.Checked)
            {
                comm = (result * .15);
                finalammount = comm + result;
            }
            else
            {
                comm = 0;
                percent = "0%";
                finalammount = comm + result;
            }

            txtTotalsales.Text = finalammount.ToString();
            commission rev = new commission();
            rev.setValues(comm, percent, finalammount);
            rev.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
