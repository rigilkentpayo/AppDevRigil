﻿namespace WindowsAct6
{
    partial class commission
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtCom = new TextBox();
            txtPeso = new TextBox();
            txtFinal = new TextBox();
            txtCo = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(352, 9);
            label1.Name = "label1";
            label1.Size = new Size(78, 32);
            label1.TabIndex = 0;
            label1.Text = "SALES";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(174, 133);
            label3.Name = "label3";
            label3.Size = new Size(184, 25);
            label3.TabIndex = 2;
            label3.Text = "Commission in Peso:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(61, 186);
            label4.Name = "label4";
            label4.Size = new Size(301, 25);
            label4.TabIndex = 3;
            label4.Text = "Final ammount of the commission:";
            // 
            // txtCom
            // 
            txtCom.Location = new Point(364, 84);
            txtCom.Name = "txtCom";
            txtCom.Size = new Size(100, 23);
            txtCom.TabIndex = 5;
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(364, 133);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(100, 23);
            txtPeso.TabIndex = 6;
            // 
            // txtFinal
            // 
            txtFinal.Location = new Point(368, 186);
            txtFinal.Name = "txtFinal";
            txtFinal.Size = new Size(100, 23);
            txtFinal.TabIndex = 7;
            // 
            // txtCo
            // 
            txtCo.AutoSize = true;
            txtCo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCo.Location = new Point(182, 79);
            txtCo.Name = "txtCo";
            txtCo.Size = new Size(176, 25);
            txtCo.TabIndex = 1;
            txtCo.Text = "Commission is/are: ";
            // 
            // commission
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtFinal);
            Controls.Add(txtPeso);
            Controls.Add(txtCom);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtCo);
            Controls.Add(label1);
            Name = "commission";
            Text = "Form1";
            Load += commission_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private TextBox txtCom;
        private TextBox txtPeso;
        private TextBox txtFinal;
        private Label txtCo;
    }
}
