﻿namespace WindowsAct6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtnum1 = new TextBox();
            txtnum2 = new TextBox();
            txtnum3 = new TextBox();
            txtTotalsales = new TextBox();
            button1 = new Button();
            groupBox1 = new GroupBox();
            chk15 = new CheckBox();
            chk10 = new CheckBox();
            chk50 = new CheckBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(352, 9);
            label1.Name = "label1";
            label1.Size = new Size(78, 32);
            label1.TabIndex = 0;
            label1.Text = "SALES";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(182, 79);
            label2.Name = "label2";
            label2.Size = new Size(77, 25);
            label2.TabIndex = 1;
            label2.Text = "January";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(182, 131);
            label3.Name = "label3";
            label3.Size = new Size(86, 25);
            label3.TabIndex = 2;
            label3.Text = "February";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(182, 181);
            label4.Name = "label4";
            label4.Size = new Size(66, 25);
            label4.TabIndex = 3;
            label4.Text = "March";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(182, 233);
            label5.Name = "label5";
            label5.Size = new Size(98, 25);
            label5.TabIndex = 4;
            label5.Text = "Total sales";
            // 
            // txtnum1
            // 
            txtnum1.Location = new Point(330, 81);
            txtnum1.Name = "txtnum1";
            txtnum1.Size = new Size(100, 23);
            txtnum1.TabIndex = 5;
            // 
            // txtnum2
            // 
            txtnum2.Location = new Point(330, 133);
            txtnum2.Name = "txtnum2";
            txtnum2.Size = new Size(100, 23);
            txtnum2.TabIndex = 6;
            // 
            // txtnum3
            // 
            txtnum3.Location = new Point(330, 186);
            txtnum3.Name = "txtnum3";
            txtnum3.Size = new Size(100, 23);
            txtnum3.TabIndex = 7;
            // 
            // txtTotalsales
            // 
            txtTotalsales.Location = new Point(330, 235);
            txtTotalsales.Name = "txtTotalsales";
            txtTotalsales.Size = new Size(100, 23);
            txtTotalsales.TabIndex = 8;
            // 
            // button1
            // 
            button1.Location = new Point(518, 246);
            button1.Name = "button1";
            button1.Size = new Size(94, 27);
            button1.TabIndex = 9;
            button1.Text = "COMPUTE";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chk15);
            groupBox1.Controls.Add(chk10);
            groupBox1.Controls.Add(chk50);
            groupBox1.Location = new Point(182, 301);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(430, 76);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Commisision";
            // 
            // chk15
            // 
            chk15.AutoSize = true;
            chk15.Location = new Point(300, 32);
            chk15.Name = "chk15";
            chk15.Size = new Size(48, 19);
            chk15.TabIndex = 2;
            chk15.Text = "15%";
            chk15.UseVisualStyleBackColor = true;
            // 
            // chk10
            // 
            chk10.AutoSize = true;
            chk10.Location = new Point(170, 32);
            chk10.Name = "chk10";
            chk10.Size = new Size(48, 19);
            chk10.TabIndex = 1;
            chk10.Text = "10%";
            chk10.UseVisualStyleBackColor = true;
            // 
            // chk50
            // 
            chk50.AutoSize = true;
            chk50.Location = new Point(35, 32);
            chk50.Name = "chk50";
            chk50.Size = new Size(48, 19);
            chk50.TabIndex = 0;
            chk50.Text = "50%";
            chk50.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(txtTotalsales);
            Controls.Add(txtnum3);
            Controls.Add(txtnum2);
            Controls.Add(txtnum1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtnum1;
        private TextBox txtnum2;
        private TextBox txtnum3;
        private TextBox txtTotalsales;
        private Button button1;
        private GroupBox groupBox1;
        private CheckBox chk15;
        private CheckBox chk10;
        private CheckBox chk50;
    }
}
