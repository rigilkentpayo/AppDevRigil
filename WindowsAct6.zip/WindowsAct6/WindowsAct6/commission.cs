namespace WindowsAct6
{
    public partial class commission : Form
    {
        public commission()
        {
            InitializeComponent();
        }
        public void setValues(double comm, String percent, double finalammount)
        {
            txtCom.Text = comm.ToString();
            txtPeso.Text = percent.ToString();
            txtFinal.Text = finalammount.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
          

        }

        private void commission_Load(object sender, EventArgs e)
        {

        }
    }
}
