﻿using AcrylicSYSTEM.DBhelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AcrylicSYSTEM
{
    public partial class Loginpage : Form
    {
        public static string sendtext = "";
       
        public Loginpage()
        {
            InitializeComponent();
        }

        private void BTNlogin_Click(object sender, EventArgs e)
        {
            //retrieving username and password from the database
            try
            {
                connection.connection.DB();
                DBhelper.DBHelper.gen = "Select * from users where [username] = '" + txtusername.Text + "' and [password] = '" + txtpassword.Text + "'";
                DBhelper.DBHelper.command = new OleDbCommand(DBhelper.DBHelper.gen, connection.connection.conn);
                DBhelper.DBHelper.reader = DBhelper.DBHelper.command.ExecuteReader();

                if (DBhelper.DBHelper.reader.HasRows)
                {
                    DBhelper.DBHelper.reader.Read();
                    //database  
                    txtusername.Text = (DBhelper.DBHelper.reader["username"].ToString());
                    txtpassword.Text = (DBhelper.DBHelper.reader["password"].ToString());
                    // open a next form  
                    //  Stocks s = new Stocks ();
                    //  s.Show();
                    //   this.Visible =false;//cosing the form
                    //   sale.Show();l

                    timer1.Enabled = true;
                    timer1.Start();
                    timer1.Interval = 1;
                    progressBar1.Maximum = 200;
                    timer1.Tick += new EventHandler(timer1_Tick);


                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");

                }
                connection.connection.conn.Close();
            }
            catch (Exception ex)
            {
                connection.connection.conn.Close();
                MessageBox.Show(ex.Message);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer1.Stop();
                this.Hide();

                progressBar1.Value = 0;
                sendtext = txtusername.Text;
                adminpage s = new adminpage();
                s.Show();
            }
        }

        private void btncreate_Click(object sender, EventArgs e)
        {
            CreateUser v = new CreateUser();
            v.Show();
            this.Hide();    
        }
    }
}
