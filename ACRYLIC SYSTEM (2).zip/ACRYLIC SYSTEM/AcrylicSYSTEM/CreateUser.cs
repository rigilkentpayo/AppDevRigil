﻿using AcrylicSYSTEM.connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AcrylicSYSTEM
{
    public partial class CreateUser : Form
    {
        
        public CreateUser()
        {
            InitializeComponent();
        }

        
        private void btnsave_Click(object sender, EventArgs e)
        {
           
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            
            string username = txtusername.Text.Trim();
            string password = txtpassword.Text.Trim();
           

            if (username == "" || password == ""  )
            {
                MessageBox.Show("Please fill in all fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                connection.connection.DB();
                string checkUserQuery = "SELECT COUNT(*) FROM users WHERE [username] = @username";
                OleDbCommand checkCmd = new OleDbCommand(checkUserQuery, connection.connection.conn);
                checkCmd.Parameters.AddWithValue("@username", username);
                int userCount = (int)checkCmd.ExecuteScalar();

                if (userCount > 0)
                {
                    MessageBox.Show("Username already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Insert new user
                string insertQuery = "INSERT INTO Users ([username], [password]) VALUES (@username, @password)";   
                OleDbCommand insertCmd = new OleDbCommand(insertQuery, connection.connection.conn);
             
                insertCmd.Parameters.AddWithValue("@username", username);
                insertCmd.Parameters.AddWithValue("@password", password);
               

                int rowsAffected = insertCmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Account created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Add any additional actions here like clearing the fields
                }
                else
                {
                    MessageBox.Show("Error creating account.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating account: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.connection.conn.Close();
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Loginpage s = new Loginpage();
            s.Show();
            this.Close();
        }

        private void CreateUser_Load(object sender, EventArgs e)
        {

        }
    }
}
